
#include<stdio.h>
#include "registro.h"

void imprimir_estado(void);


int main()
{
    printf("Ingrese el número (del 0 al 7) del LED que se desea prender\n");
    printf("Ingrese la letra 't'para que todos los LEDs deben cambiar al estado opuesto \n");
    printf("Ingrese la letra 'c', para que se apaguen todos, y 's', para que se prendan todos\n");
    printf("Ingrese la letra 'q' para que el programa finalize\n");
    int c;
    while(((c = getchar()) != 'q') && (c!= 'Q'))
    {
        if(c == 't' || c== 'T')
        {
        for(int i=0 ; i<8 ; i++)
        bitToggle('A', i);
        imprimir_estado();
        }

        else if(c == 's' || c == 'S')
        {
        for(int i=0 ; i<8 ; i++)
        bitSet('A', i);
        imprimir_estado();
        }

        else if(c == 'c' || c == 'C')
        {
        for(int i=0 ; i<8 ; i++)
        bitClr('A', i);
        imprimir_estado();
        }

        else if(c>='0' && c<='7'){
        bitSet('A', (c-'0'));
        imprimir_estado();
        }
    }

}

void imprimir_estado(void){
    for(int i=0 ; i<8 ; i++)
       {
       	printf("Estado del bit %d: %d\n", i, bitGet('A', i));
       }
}
