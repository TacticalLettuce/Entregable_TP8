/*
 * registro.c
 *
 *  Created on: May 24, 2025
 *      Author: progra
 */


#include "registro.h"
#include <stdint.h>
static Puertos_t registro; //sólo accesible dentro de este archivo, el tipo Puertos_t esta en el .h

//FUNCIONES
void bitSet(char puerto, uint8_t bit)
{
switch(puerto){

    case 'a':
    case 'A':
     if(bit<8)
   {
    registro.A_B.A |= (1<<bit);
   }
    break;

    case 'b':
    case 'B':
    if(bit<8)
   {
    registro.A_B.B |= (1<<bit);
   }
    break;

    case 'd':
    case 'D':

   if(bit<16)
   {
    registro.D |= (1<<bit);
   }
    break;

}
}

    void bitClr(char puerto, uint8_t bit)
{
switch(puerto){

    case 'a':
    case 'A':

    if(bit<8) //"proteccion"
   {
    registro.A_B.A &= ~(1<<bit);
   }
     break;

    case 'b':
    case 'B':

    if(bit<8) //"proteccion"
   {
    registro.A_B.B &= ~(1<<bit);
   }
    break;

    case 'd':
    case 'D':

    if (bit<16) //"proteccion"
   {
    registro.D &= ~(1<<bit);
    }
    break;
}
}

    void bitToggle(char puerto, uint8_t bit)
{
switch(puerto){

    case 'a':
    case 'A':

    if(bit<8) //"proteccion"
   {
    registro.A_B.A ^= (1<<bit);
   }
     break;

    case 'b':
    case 'B':

    if(bit<8) //"proteccion"
   {
    registro.A_B.B ^= (1<<bit);
   }
    break;

    case 'd':
    case 'D':

    if (bit<16) //"proteccion"
   {
    registro.D ^= (1<<bit);
    }
    break;
}
}

uint8_t bitGet(char puerto, uint8_t bit)
{
switch(puerto){

    case 'a':
    case 'A':

    if(bit<8) //"proteccion"
   {
    return ((registro.A_B.A >> bit) & 1);
   }
     break;

    case 'b':
    case 'B':

    if(bit<8) //"proteccion"
   {
    return ((registro.A_B.B >> bit) & 1);
   }
    break;

    case 'd':
    case 'D':

    if (bit<16) //"proteccion"
   {
    return ((registro.D >> bit) & 1);
    }
    break;
}
	return 0;
}

void maskOn(char puerto, uint16_t mascara){
switch(puerto){

    case 'a':
    case 'A':

     registro.A_B.A |= (uint8_t)mascara; //Casteo la mascara para que su parte alta sean todos ceros

     break;

    case 'b':
    case 'B':

     registro.A_B.B |= (uint8_t)mascara; //Casteo la mascara para que su parte alta sean todos ceros

    break;

    case 'd':
    case 'D':


     registro.D |= mascara;

    break;
}
}

void maskOff(char puerto, uint16_t mascara){
switch(puerto){

    case 'a':
    case 'A':

     registro.A_B.A &= (uint8_t)(~mascara); //Casteo la mascara para que su parte alta sean todos ceros

     break;

    case 'b':
    case 'B':

     registro.A_B.B &= (uint8_t)(~mascara); //Casteo la mascara para que su parte alta sean todos ceros

    break;

    case 'd':
    case 'D':


     registro.D &= (~mascara);

    break;
}
}

void maskToggle(char puerto, uint16_t mascara){
switch(puerto){

    case 'a':
    case 'A':

     registro.A_B.A ^= (uint8_t)(mascara); //Casteo la mascara para que su parte alta sean todos ceros

     break;

    case 'b':
    case 'B':

     registro.A_B.B ^= (uint8_t)(mascara); //Casteo la mascara para que su parte alta sean todos ceros

    break;

    case 'd':
    case 'D':


     registro.D ^= (mascara);

    break;
}
}
