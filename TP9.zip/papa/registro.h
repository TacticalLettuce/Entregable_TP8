/*
 * registro.h
 *
 *  Created on: May 24, 2025
 *      Author: progra
 */

#ifndef REGISTRO_H_
#define REGISTRO_H_

#ifndef PUERTOS_H
#define PUERTOS_H
#include <stdint.h>

// Definición de la unión para los puertos A, B y D
typedef union {
    uint16_t D;  // Puerto combinado de 16 bits
    struct {
        uint8_t B;   // Parte baja
        uint8_t A;   // Parte alta
    } A_B;
} Puertos_t;

// Operaciones sobre bits individuales
void bitSet(char puerto, uint8_t bit);
void bitClr(char puerto, uint8_t bit);
void bitToggle(char puerto, uint8_t bit);
uint8_t bitGet(char puerto, uint8_t bit);

void maskOn(char puerto, uint16_t mascara);
void maskOff(char puerto, uint16_t mascara);
void maskToggle(char puerto, uint16_t mascara);

#endif // PUERTOS_H

#endif /* REGISTRO_H_ */
